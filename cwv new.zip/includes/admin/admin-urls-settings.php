<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
?><div class="cwvpsb-table-url-wrapper"><table class="table cwvpsb-table-class" id="table_page_cc_style" style="width:100%">
    <thead>
            <tr>
                <th>URL</th>
                <th>Status</th>
                <th>Size</th>
                <th>Created date</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>URL</th>
                <th>Status</th>
                <th>Size</th>
                <th>Created date</th>
            </tr>
        </tfoot>
</table></div><?php